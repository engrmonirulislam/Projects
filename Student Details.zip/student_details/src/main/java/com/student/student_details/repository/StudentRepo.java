package com.student.student_details.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.student.student_details.data.StudentEntities;

public interface StudentRepo extends JpaRepository<StudentEntities, Long>{

}
