package com.student.student_details.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.student.student_details.data.StudentEntities;
import com.student.student_details.repository.StudentRepo;

@RestController
public class StudentController {
	
	@Autowired
	StudentRepo studentRepo;
	
	@PostMapping("/student")
	StudentEntities addStudent(@RequestBody StudentEntities studentEntities)
	{
		return studentRepo.save(studentEntities);
	}
	
	@GetMapping("/students")
	List<StudentEntities> seeStudents()
	{
		return studentRepo.findAll();
	}

}
